#ifndef IRREMOTEEXT_H
#define IRREMOTEEXT_H

typedef void (*__ir_handler_type)(unsigned long);

extern void beginIRremote(int pin);

extern void addPressHandlerIRremote(unsigned long code, __ir_handler_type func);
extern void addReleaseHandlerIRremote(unsigned long code, __ir_handler_type func);

extern void handelIRremote();
extern unsigned long getPressedIRremote();
extern bool isReleasedIRremote(unsigned long code);


#define IR_CODE_PWR		0x01FE48B7
#define IR_CODE_MODE	0x01FE58A7
#define IR_CODE_MUTE	0x01FE7887
#define IR_CODE_PLAY/PAUSE	0x01FE807F
#define IR_CODE_REWIND	0x01FE40BF
#define IR_CODE_FORWARD	0x01FEC03F
#define IR_CODE_EQ	0x01FE20DF
#define IR_CODE_VOL-	0x01FEA05F
#define IR_CODE_VOL+	0x01FE609F
#define IR_CODE_0  	0x01FEE01F
#define IR_CODE_RPT	0x01FE10EF
#define IR_CODE_U/SD	0x01FE906F
#define IR_CODE_1		0x01FE50AF
#define IR_CODE_2		0x01FED827
#define IR_CODE_3		0x01FEF807
#define IR_CODE_4		0x01FE30CF
#define IR_CODE_5		0x01FEB04F
#define IR_CODE_6		0x01FE708F
#define IR_CODE_7		0x01FE00FF
#define IR_CODE_8		0x01FEF00F
#define IR_CODE_9		0x01FE9867


#endif